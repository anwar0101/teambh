<div class="footer-bg-color" style="margin-top:70px;">
  <div class="container">
    <div class="row">
      <div class="col-md-3 hidden-xs">
        <p> Learn More </p>
        <ul class="nav nav-pills nav-stacked">
          <li><a href="#"> How to sell fast </a></li>
          <li><a href="#"> Buy Now on </a></li>
          <li><a href="#"> Membership </a></li>
          <li><a href="#"> Banner Advertising </a></li>
          <li><a href="#"> Promote your ad </a></li>
        </ul>
      </div>

      <div class="col-md-2 hidden-xs">
        <p> Help & Support </p>
        <ul class="nav nav-pills nav-stacked">
          <li> <a href="#"> FAQ </a></li>
          <li> <a href="#"> Stay Safe On </a></li>
          <li> <a href="#"> Contact Us </a></li>
        </ul>
      </div>

      <div class="col-md-2">
        <p> Follow Us </p>
        <ul class="nav nav-pills nav-stacked">
          <li> <a href="#"> Facebook </a></li>
          <li> <a href="#"> Twitter </a></li>
          <li> <a href="#"> Google+ </a></li>
        </ul>
      </div>

      <div class="col-md-2">
        <p> About Us </p>
        <ul class="nav nav-pills nav-stacked">
          <li> <a href="#"> About Us </a></li>
          <li> <a href="#"> Career </a></li>
          <li> <a href="#"> Term & Conditions  </a></li>
          <li> <a href="#"> Privacy Policy </a></li>
          <li> <a href="#"> Sitemap </a></li>
        </ul>
      </div>

      <div class="col-md-3">
        <p> Download Our App </p>
        <p>
          <button type="button" class="btn btn-success btn-lg"> <i class="fa fa-android fa-lg"></i>  DOWNLOAD NOW </button>
        </p>
        {{-- <p>
          <button type="button" class="btn btn-success btn-lg"> <i class="fa fa-apple fa-lg"></i>  DOWNLOAD NOW </button>
        </p> --}}
      </div>
    </div>
  </div>

  <div class="container">
    <hr>
    <div class="row">
      <div class="col-md-6">
        Copyright &copy; koridbiki.com
      </div>
      <div class="col-md-6">
        <p class="text-right"> All Right Reserved 2017-2018 </p>
      </div>
    </div>
  </div>
</div>
