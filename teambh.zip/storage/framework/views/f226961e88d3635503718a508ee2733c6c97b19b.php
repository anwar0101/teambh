<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
      <div class="col-md-4">
        
        <?php echo $__env->make('includes.user-left-nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
      </div>
      <div class="col-md-8">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h1 class="panel-title"> Favourites </h1>
          </div>
          <div class="panel-body">
            <?php $__empty_1 = true; $__currentLoopData = $favorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favorite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(route('post.show', $favorite->post->id)); ?>">
                  <div class="panel panel-default item-sty">
                    <div class="panel-body">
                      <div class="row media">
                        <div class="col-md-3 col-sm-4">
                          <div class="media-left">
                            <img class="img-responsive" src="<?php echo e(asset(str_replace_last('public', 'storage', $favorite->post->photo1))); ?>" alt="Post image">
                          </div>
                        </div>
                        <div class="col-md-7">
                          <div class="media-body">
                            <p class="media-heading"> <?php echo e($favorite->post->title); ?> </p>
                            <p class="text-muted"> <b class="label label-default"> member </b> &nbsp; <wbr> <?php echo e($favorite->post->created_at->diffForHumans()); ?>, <wbr> <?php echo e($favorite->post->place->name); ?>,<wbr> <?php echo e($favorite->post->sub_category->name); ?> </p>
                            <p> <b> Tk <?php echo e($favorite->post->price); ?> </b> </p>
                          </div>
                        </div>
                        <div class="col-md-2">
                          <div class="media-right">
                            <p class="label label-warning"> <i class="fa fa-star-o"></i> FAVORITE </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-center">
                  <h3> You haven't marked any ads as favorite yet. </h3>
                  <p> Click on the star symbol on any ad to save it as a favorite. </p>
                  <p> <i class="fa fa-star-o fa-5x text-primary"></i> </p>
                  <p> Start<a href="<?php echo e(route('ads.index')); ?>"> to browse </a>ads to find ads you would like to favorite.</p>
                </div>
            <?php endif; ?>

          </div>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>