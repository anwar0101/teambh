<nav class="navbar navbar-default">
    <div class="container">
        <div class="navbar-header">

            <!-- Collapsed Hamburger -->
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                <span class="sr-only">Toggle Navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

            <!-- Branding Image -->
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <i class="fa fa-exchange" aria-hidden="true"></i> <?php echo e(config('app.name', 'Koridbiki.com')); ?>

            </a>
        </div>

        <div class="collapse navbar-collapse" id="app-navbar-collapse">
            <!-- Left Side Of Navbar -->
            <ul class="nav navbar-nav">
                <li> <a href="<?php echo e(route('ads.index')); ?>"> <i class="fa fa-eye fa-fw"></i> All Ads </a> </li>
                <li> <a href="<?php echo e(route('post.index')); ?>"> <i class="fa fa-paper-plane-o fa-fw"></i> Post Your Ad </a> </li>
            </ul>

            <!-- Right Side Of Navbar -->
            <ul class="nav navbar-nav navbar-right">
                <!-- Authentication Links -->
                <?php if(Auth::guest()): ?>
                    <li><a href="<?php echo e(route('login')); ?>"> <i class="fa fa-sign-in fa-fw"> </i> Login </a> </li>
                    <li><a href="<?php echo e(route('register')); ?>"> <i class="fa fa-user-plus fa-fw"> </i> Register </a> </li>
                <?php else: ?>
                    <li> <a href="<?php echo e(route('dashboard')); ?>"> <i class="fa fa-user-circle-o fa-fw"></i> My Account </a> </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                            <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                        </a>

                        <ul class="dropdown-menu" role="menu">
                            <li>
                                <a href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                    Logout
                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
