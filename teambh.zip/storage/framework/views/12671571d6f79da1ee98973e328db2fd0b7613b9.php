<?php $__env->startSection('content'); ?>
  <div class="header-bg-color">
    <div class="container">
      <div class="row">
        <div class="col-md-3">
          <h3> Search by Division </h3>
          <div class="list-group">
            <?php $__currentLoopData = $divitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $divition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('ads.index')); ?>" class="list-group-item"> <?php echo e($divition->name); ?> </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
        <div class="col-md-9">
          <div class="row">
            <div class="col-md-12">
              <h1 class="text-center text-primary"> Welcome to <?php echo e(Voyager::setting("admin.title", "Koridbiki.com")); ?> </h1>
              <p class="text-center">
                  <?php echo e(Voyager::setting("home.welcome_message", "Buy and sell everything new and/or used like cars to mobile phones and computers ect or search for property,
                 jobs and more in Bangladesh - for free!")); ?>

              </p>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 top-category-gap">
              <div class="panel panel-default">
                <div class="panel-heading">
                  <h1 class="panel-title"> Browse our top categories </h1>
                </div>
                <div class="panel-body">
                  <div class="row">
                      <?php $__currentLoopData = $poupulers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="col-md-3">
                            <a href="<?php echo e(route('ads.index')); ?>">
                              <p class="text-center"> <i class="fa <?php echo e($cat->icon); ?> fa-2" aria-hidden="true"></i></p>
                              <h4 class="text-center text-primary"> <?php echo e($cat->name); ?> </h4>
                            </a>
                          </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="content-bg-color">
      <div class="row">

          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-3">
                <div class="item-sty">
                  <a href="<?php echo e(route('ads.index')); ?>">
                    <p class="text-center"> <i class="fa <?php echo e($cat->icon); ?> fa-2x" aria-hidden="true"></i></p>
                    <h4 class="text-center text-primary"> <?php echo e($cat->name); ?> </h4>
                  </a>
                  <p class="text-justify">
                    <?php echo e($cat->description); ?>

                  </p>
                </div>
              </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>