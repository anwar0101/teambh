<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="content-bg-color">
      <h3> <?php echo e($post->title); ?> </h3>
      <p> For sale by <?php echo e($post->user->name); ?> <?php echo e($post->created_at->toDayDateTimeString()); ?>, <?php echo e($post->place->name); ?>, <?php echo e($post->place->divition->name); ?> </p>

      <div class="row">
        <div class="col-md-8">
          <!-- carousel section start here -->
          <div id="myCarousel" class="carousel slide" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
              <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
              <?php if($post->photo2): ?>
                  <li data-target="#myCarousel" data-slide-to="1"></li>
              <?php endif; ?>
              <?php if($post->photo3): ?>
                  <li data-target="#myCarousel" data-slide-to="2"></li>
              <?php endif; ?>
              <?php if($post->photo4): ?>
                  <li data-target="#myCarousel" data-slide-to="3"></li>
              <?php endif; ?>
            </ol>
            <!-- Wrapper for slides start -->
            <div class="carousel-inner">

              <div class="item active">
                <img class="img-responsive" src="<?php echo e(asset(str_replace_last('public', 'storage', $post->photo1))); ?>" alt="photo 1">
                <div class="carousel-caption">
                  <h3> Koridbiki.com </h3>
                </div>
              </div>

              <?php if($post->photo2): ?>
                  <div class="item">
                    <img class="img-responsive" src="<?php echo e(asset(str_replace_last('public', 'storage', $post->photo2))); ?>" alt="photo 2">
                    <div class="carousel-caption">
                      <h3> Koridbiki.com </h3>
                    </div>
                  </div>
              <?php endif; ?>

              <?php if($post->photo3): ?>
                  <div class="item">
                    <img class="img-responsive" src="<?php echo e(asset(str_replace_last('public', 'storage', $post->photo3))); ?>" alt="photo 3">
                    <div class="carousel-caption">
                      <h3> Koridbiki.com </h3>
                    </div>
                  </div>
              <?php endif; ?>

              <?php if($post->photo4): ?>
                  <div class="item">
                    <img class="img-responsive" src="<?php echo e(asset(str_replace_last('public', 'storage', $post->photo4))); ?>" alt="photo 4">
                    <div class="carousel-caption">
                      <h3> Koridbiki.com </h3>
                    </div>
                  </div>
              <?php endif; ?>

            </div> <!-- Wrapper for slides start -->

            <!-- Left and right controls -->
            <a class="left carousel-control" href="#myCarousel" data-slide="prev">
              <span class="glyphicon glyphicon-chevron-left"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control" href="#myCarousel" data-slide="next">
              <span class="glyphicon glyphicon-chevron-right"></span>
              <span class="sr-only">Next</span>
            </a>
          </div> <hr> <!-- carousel section start here -->

          <div class="row">
            <div class="col-md-8">
              <p> <b class="style-for-money"> Tk <?php echo e($post->price); ?> </b> <?php if($post->negatiable == 1): ?>
                  (Negatiable)
              <?php else: ?>
                  (Fixed)
              <?php endif; ?> </p> <hr>
              <p>
                <?php echo e($post->description); ?>

              </p>
            </div>
            <div class="col-md-4">
              <ul class="list-group">
                <?php $__currentLoopData = $post->extra_values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $extra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item"> <p> <b> <?php echo e($key); ?>: </b> <?php echo e($extra); ?> </p> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <li class="list-group-item"> <a href="<?php echo e(route('favorite.check', $post->id)); ?>">  <?php if($post->is_favorited): ?><i class="fa fa-star"></i> Unfavourite this ad <?php else: ?> <i class="fa fa-star-o"></i> Save ad as Fovourite <?php endif; ?> </a> </li>
                <li class="list-group-item"> <a href="#"> <i class="fa fa-ban"></i> Report this ad </a> </li>
              </ul>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <p> Contact now with seller </p>
          <ul class="list-group">
            <li class="list-group-item">
              <b> <i class="fa fa-mobile-phone fa-fw fa-lg"></i> <?php echo e($post->contact); ?>  </b>
            </li>
          </ul>
          <?php if($post->user->role->name == 'member'): ?>
              <p> Visit member's page </p>
              <ul class="list-group">
                <a href="#" class="list-group-item">
                  <div class="row">
                    <div class="col-md-4">
                      <img class="img-responsive" src="/img/my.jpeg" alt="Los Angeles">
                    </div>
                    <div class="col-md-8">
                      <p> Trust SecuritiesBD </p>
                      <p> Your Trusted Partner</p>
                    </div>
                  </div>
                </a>
              </ul>
              <p> Visit member's page </p>
              <ul class="list-inline">
                <a href="#"> <i class="fa fa-facebook-square fa-3x text-info"></i> </a> &nbsp; &nbsp;
                <a href="#"> <i class="fa fa-twitter-square fa-3x"></i> </a> &nbsp; &nbsp;
                <a href="#"> <i class="fa fa-google-plus-square fa-3x text-danger"></i> </a>
              </ul>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <!-- show the similar product to user section start -->
    <div class="content-bg-color">
      <h3> Similar Ads </h3> <hr>
        <div class="row">
          <div class="col-md-8 col-md-offset-2">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($pos->id != $post->id): ?>
                    <a href="<?php echo e(route('post.show', $pos->id)); ?>">
                      <div class="panel panel-default item-sty">
                        <div class="panel-body">
                          <div class="row media">
                            <div class="col-md-3 col-sm-4">
                              <div class="media-left">
                                <img class="img-responsive" src="<?php echo e(asset(str_replace_last('public', 'storage', $pos->photo1))); ?>" alt="<?php echo e($pos->title); ?>">
                              </div>
                            </div>
                            <div class="col-md-7 col-sm-8">
                              <div class="media-body">
                                <p class="media-heading"> <?php echo e($pos->title); ?> </p>
                                <p class="text-muted"> <b class="label label-default"> member </b> &nbsp; <wbr> <?php echo e($post->created_at->diffForHumans()); ?>, <wbr> <?php echo e($post->place->name); ?>,<wbr> <?php echo e($post->sub_category->name); ?> </p>
                                <p> <b> Tk <?php echo e($post->price); ?> </b> </p>
                              </div>
                            </div>
                            <div class="col-md-2">
                              <div class="media-right">
                                <p class="label label-success"> <i class="fa fa-shield"></i> TOP PAID </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>
        </div>
    </div> <!-- show the similar product to user section start -->

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>