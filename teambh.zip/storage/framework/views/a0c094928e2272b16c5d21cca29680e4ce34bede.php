<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
      <div class="col-md-4">
          
          <?php echo $__env->make('includes.user-left-nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          
      </div>
      <div class="col-md-8">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h1 class="panel-title"> Settings </h1>
          </div>
          <div class="panel-body">
            <h3> Change details </h3> <hr>
            <p> <span> <i class="fa fa-envelope-o fa-fw"></i> Email: </span>  <b> <?php echo e(Auth::user()->email); ?></b> </p>
            <form class="" action="index.html" method="post">
                <?php echo e(csrf_field()); ?>

              <div class="row">
                <div class="col-md-6 col-md-offset-right-6">
                  <div class="form-group">
                    <label for="name"> Name </label>
                    <div class="input-group">
                      <span class="input-group-addon"> <i class="fa fa-user-o"></i></span>
                      <input class="form-control" type="text" name="name" value="<?php echo e(Auth::user()->name); ?>">
                    </div>
                  </div>
                </div>
              </div>

              <div class="row">

                <div class="form-group col-md-6 col-sm-12">
                    <label for="divition">Divition</label>
                    <select class="form-control" name="divition_id" id="divition_id">
                        <?php $__currentLoopData = $divitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $divition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($divition->id); ?>"><?php echo e($divition->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group col-md-6 col-sm-12">
                    <label for="place_id">Palce</label>
                    <select class="form-control" name="place_id" id="place_id">
                        <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($place->id); ?>"><?php echo e($place->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

              </div>
              <div class="text-right">
                <button type="submit" class="btn btn-default"> <i class="fa fa-pencil-square-o fa-fw"></i> Update Now </button>
              </div>
            </form>
            <!-- Second form for change password -->
            <h3> Change Password </h3> <hr>
            <form class="" action="index.html" method="post">
                <?php echo e(csrf_field()); ?>

              <div class="row">
                <div class="col-md-6 col-md-offset-3">
                  <div class="form-group">
                    <label for="name"> Current Password </label>
                    <div class="input-group">
                      <span class="input-group-addon"> <i class="fa fa-lock"></i></span>
                      <input class="form-control" type="password" name="password">
                    </div>
                  </div>
                </div>
              </div>

              <div class="row">
                <div class="col-md-6 col-md-offset-3">
                  <div class="form-group">
                    <label for="name"> New Password </label>
                    <div class="input-group">
                      <span class="input-group-addon"> <i class="fa fa-plus"></i></span>
                      <input class="form-control" type="password" name="new_password">
                    </div>
                  </div>
                </div>
              </div>

              <div class="row">
                <div class="col-md-6 col-md-offset-3">
                  <div class="form-group">
                    <label for="name"> Confirm Password </label>
                    <div class="input-group">
                      <span class="input-group-addon"> <i class="fa fa-check-square-o"></i></span>
                      <input class="form-control" type="password">
                    </div>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6 col-md-offset-3 text-right">
                  <button type="submit" class="btn btn-default"> <i class="fa fa-paper-plane fa-fw"></i> Change Password </button>
                </div>
              </div>
            </form>
            

          </div>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">

        var places = {
            <?php $__currentLoopData = $divitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $divition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(count($divition->places)>0): ?>
                    "<?php echo e($divition->id); ?>":[
                            <?php $__currentLoopData = $divition->places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                { "name":"<?php echo $place->name; ?>","id":"<?php echo e($place->id); ?>" },
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ],
                <?php else: ?>
                    "<?php echo e($divition->id); ?>":[],
                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        };


        $(function() {

            $(document).on('change','#divition_id',function(){
                var subplaces = places[this.value];
                var subplacesOpt = $.map(subplaces, function ( item, i) {
                    return $('<option>', { text: item.name, value: item.id });
                });
                $("#place_id").empty().append(subplacesOpt);
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>