<?php $__env->startSection('css'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
    <h1 class="page-title">
        All Unpulished Ads
    </h1>
    <?php echo $__env->make('voyager::multilingual.language-selector', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content edit-add container-fluid">
        <div class="row">
            <div class="col-md-12">

                <div class="panel panel-bordered">
                    <table class="table table-bordered">
                        <thead>
                            <th>title</th>
                            <th>Category</th>
                            <th>price</th>
                            <th>actions</th>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($post->title); ?></td>
                                    <td><?php echo e($post->sub_category->category->name); ?> , <?php echo e($post->sub_category->name); ?></td>
                                    <td><?php echo e($post->price); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('post.show',$post->id)); ?>" target="_top"><button type="button" name="btn btn-sm btn-success">View</button></a>
                                        <a href="<?php echo e(route('post.status',[$post->id,1])); ?>"><button type="button" name="btn btn-sm btn-success">PUBLISH</button></a>
                                        <a href="<?php echo e(route('post.status',[$post->id,3])); ?>/3"><button type="btn btn-sm btn-danger" name="button">REJECT</button></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-center">All Ads are reviewed.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>