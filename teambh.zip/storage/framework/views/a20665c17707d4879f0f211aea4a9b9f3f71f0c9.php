<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="content-bg-color">
      <h3 class="text-center"> Welcome <?php echo e(Auth::user()->name); ?>, Let's post an ad. Choose any option below:</h3>
      <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <form class="" action="<?php echo e(route('post.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="form-group col-md-6 col-sm-12">
                    <label for="category_id">Category</label>
                    <select class="form-control" name="category_id" id="category_id">
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group col-md-6 col-sm-12">
                    <label for="sub_category_id">Sub Category</label>
                    <select class="form-control" name="sub_category_id" id="sub_category_id">
                        <?php $__currentLoopData = $subcat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sub->id); ?>"><?php echo e($sub->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group col-md-6 col-sm-12">
                    <label for="divition">Divition</label>
                    <select class="form-control" name="divition_id" id="divition_id">
                        <?php $__currentLoopData = $divitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $divition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($divition->id); ?>"><?php echo e($divition->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group col-md-6 col-sm-12">
                    <label for="place_id">Palce</label>
                    <select class="form-control" name="place_id" id="place_id">
                        <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($place->id); ?>"><?php echo e($place->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group col-md-12 col-sm-12">
                    <label for="title">Title</label>
                    <input type="text" name="title" placeholder="title" class="form-control">
                </div>
                <div class="form-group col-md-12 col-sm-12">
                    <label for="description">Description</label>
                    <textarea name="description" class="form-control" placeholder="Description" rows="4" cols="80"></textarea>
                </div>

                <div class="form-group col-md-6 col-sm-12">
                    <label for="photo1">Photo 1</label>
                    <input type="file" name="photo1">
                </div>
                <div class="form-group col-md-6 col-sm-12">
                    <label for="photo2">Photo 2</label>
                    <input type="file" name="photo2" >
                </div>
                <div class="form-group col-md-6 col-sm-12 hidden-xs" id="photo3">
                    <label for="photo3">Photo 3</label>
                    <input type="file" name="photo3">
                </div>
                <div class="form-group col-md-6 col-sm-12 hidden-xs" id="photo4">
                    <label for="photo4">Photo 4</label>
                    <input type="file" name="photo4">
                </div>

                <div class="visible-xs w3-margin-left">
                    <button type="button" name="button" class="btn btn-warning btn-xs">Add More</button>
                </div>

                <div class="col-md-12 col-sm-12">
                    <div class="form-group">
                        <label for="price">Price</label>
                        <div class="input-group">
                          <input type="text" name="price" class="form-control" placeholder="Price">
                          <label class="input-group-addon">
                            <input type="checkbox" name="negatiable" value="1"> Negatiable
                          </label>
                        </div>
                    </div>
                </div>

                <div class="form-group col-md-12 col-sm-12" id="loading" hidden="hidden">
                    <h1 class="text-center"><i class="fa fa-spinner fa-spin fa-4x"></i></h1>
                </div>

                <div class="col-md-12 col-sm-12 form-group" id="extra_fields" style="padding:0px">

                </div>

                <div class="form-group col-md-12 col-sm-12">
                  <label for="contact">Contact No</label>
                  <input type="text" class="form-control" name="contact" id="contact" placeholder="01722635...">
                </div>
                <div class="col-md-10 col-sm-12">
                    <button type="submit" name="button" class="btn btn-primary w3-magrin-left">Post</button>
                </div>
            </form>
        </div>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        var cats = {
            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(count($cat->sub_categories)>0): ?>
                    "<?php echo e($cat->id); ?>":[
                            <?php $__currentLoopData = $cat->sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                { "name":"<?php echo $sub->name; ?>","id":"<?php echo e($sub->id); ?>" },
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ],
                <?php else: ?>
                    "<?php echo e($cat->id); ?>":[],
                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        };

        var places = {
            <?php $__currentLoopData = $divitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $divition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(count($divition->places)>0): ?>
                    "<?php echo e($divition->id); ?>":[
                            <?php $__currentLoopData = $divition->places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                { "name":"<?php echo $place->name; ?>","id":"<?php echo e($place->id); ?>" },
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ],
                <?php else: ?>
                    "<?php echo e($divition->id); ?>":[],
                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        };


        $(function() {
            $( document ).ready(function() {
              $("#sub_category_id").change();
            });

            $('#loading').bind('ajaxStart', function(){
                $(this).show();
            }).bind('ajaxStop', function(){
                $(this).hide();
            });

            $(document).on('change','#category_id',function(){
                var subcats = cats[this.value];
                var subcatsOpt = $.map(subcats, function ( item, i) {
                    return $('<option>', { text: item.name, value: item.id });
                });
                $("#sub_category_id").empty().append(subcatsOpt);

                $("#sub_category_id").change();
            });

            $(document).on('change','#divition_id',function(){
                var subplaces = places[this.value];
                var subplacesOpt = $.map(subplaces, function ( item, i) {
                    return $('<option>', { text: item.name, value: item.id });
                });
                $("#place_id").empty().append(subplacesOpt);
            });

            $(document).on('change','#sub_category_id',function(){
                $("#extra_fields").empty();
                $.ajax({
                      url: '/extra_fields/' + this.value,
                      success: function(html){
                          console.log(html);
                        $('#extra_fields').append(html);
                      }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>